﻿namespace WinFormsApp1
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            splitContainer1 = new SplitContainer();
            label1 = new Label();
            button7 = new Button();
            button6 = new Button();
            button5 = new Button();
            button4 = new Button();
            button3 = new Button();
            button2 = new Button();
            button1 = new Button();
            label5 = new Label();
            label4 = new Label();
            panel6 = new Panel();
            label9 = new Label();
            pictureBox6 = new PictureBox();
            panel5 = new Panel();
            label8 = new Label();
            pictureBox5 = new PictureBox();
            panel4 = new Panel();
            label7 = new Label();
            pictureBox4 = new PictureBox();
            panel3 = new Panel();
            label6 = new Label();
            pictureBox3 = new PictureBox();
            panel2 = new Panel();
            label3 = new Label();
            pictureBox2 = new PictureBox();
            panel1 = new Panel();
            label2 = new Label();
            pictureBox1 = new PictureBox();
            ((System.ComponentModel.ISupportInitialize)splitContainer1).BeginInit();
            splitContainer1.Panel1.SuspendLayout();
            splitContainer1.Panel2.SuspendLayout();
            splitContainer1.SuspendLayout();
            panel6.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox6).BeginInit();
            panel5.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox5).BeginInit();
            panel4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox4).BeginInit();
            panel3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox3).BeginInit();
            panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).BeginInit();
            panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            SuspendLayout();
            // 
            // splitContainer1
            // 
            splitContainer1.Dock = DockStyle.Fill;
            splitContainer1.Location = new Point(0, 0);
            splitContainer1.Name = "splitContainer1";
            // 
            // splitContainer1.Panel1
            // 
            splitContainer1.Panel1.BackColor = Color.FromArgb(78, 52, 46);
            splitContainer1.Panel1.Controls.Add(label1);
            splitContainer1.Panel1.Controls.Add(button7);
            splitContainer1.Panel1.Controls.Add(button6);
            splitContainer1.Panel1.Controls.Add(button5);
            splitContainer1.Panel1.Controls.Add(button4);
            splitContainer1.Panel1.Controls.Add(button3);
            splitContainer1.Panel1.Controls.Add(button2);
            splitContainer1.Panel1.Controls.Add(button1);
            // 
            // splitContainer1.Panel2
            // 
            splitContainer1.Panel2.BackgroundImage = (Image)resources.GetObject("splitContainer1.Panel2.BackgroundImage");
            splitContainer1.Panel2.BackgroundImageLayout = ImageLayout.Stretch;
            splitContainer1.Panel2.Controls.Add(label5);
            splitContainer1.Panel2.Controls.Add(label4);
            splitContainer1.Panel2.Controls.Add(panel6);
            splitContainer1.Panel2.Controls.Add(panel5);
            splitContainer1.Panel2.Controls.Add(panel4);
            splitContainer1.Panel2.Controls.Add(panel3);
            splitContainer1.Panel2.Controls.Add(panel2);
            splitContainer1.Panel2.Controls.Add(panel1);
            splitContainer1.Size = new Size(1252, 753);
            splitContainer1.SplitterDistance = 286;
            splitContainer1.TabIndex = 0;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI", 22.2F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label1.ForeColor = SystemColors.ButtonHighlight;
            label1.Location = new Point(40, 50);
            label1.Name = "label1";
            label1.Size = new Size(207, 100);
            label1.TabIndex = 2;
            label1.Text = "Alp's Angel\r\n Chocolate";
            label1.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // button7
            // 
            button7.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            button7.Location = new Point(72, 573);
            button7.Name = "button7";
            button7.Size = new Size(152, 41);
            button7.TabIndex = 0;
            button7.Text = "Promos";
            button7.UseVisualStyleBackColor = true;
            // 
            // button6
            // 
            button6.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            button6.Location = new Point(72, 509);
            button6.Name = "button6";
            button6.Size = new Size(152, 41);
            button6.TabIndex = 0;
            button6.Text = "Categories";
            button6.UseVisualStyleBackColor = true;
            // 
            // button5
            // 
            button5.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            button5.Location = new Point(70, 443);
            button5.Name = "button5";
            button5.Size = new Size(152, 41);
            button5.TabIndex = 0;
            button5.Text = "Your Order Reciepts";
            button5.UseVisualStyleBackColor = true;
            // 
            // button4
            // 
            button4.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            button4.Location = new Point(70, 379);
            button4.Name = "button4";
            button4.Size = new Size(152, 41);
            button4.TabIndex = 0;
            button4.Text = "Ratings";
            button4.UseVisualStyleBackColor = true;
            // 
            // button3
            // 
            button3.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            button3.Location = new Point(70, 312);
            button3.Name = "button3";
            button3.Size = new Size(152, 41);
            button3.TabIndex = 1;
            button3.Text = "Chocolates";
            button3.UseVisualStyleBackColor = true;
            // 
            // button2
            // 
            button2.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            button2.Location = new Point(70, 253);
            button2.Name = "button2";
            button2.Size = new Size(152, 41);
            button2.TabIndex = 0;
            button2.Text = "All Products";
            button2.UseVisualStyleBackColor = true;
            // 
            // button1
            // 
            button1.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            button1.Location = new Point(70, 192);
            button1.Name = "button1";
            button1.Size = new Size(152, 41);
            button1.TabIndex = 0;
            button1.Text = "Top Picks";
            button1.UseVisualStyleBackColor = true;
            button1.Click += button1_Click;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.BackColor = Color.Transparent;
            label5.Font = new Font("Segoe UI", 22.2F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label5.Location = new Point(25, 24);
            label5.Name = "label5";
            label5.Size = new Size(229, 100);
            label5.TabIndex = 7;
            label5.Text = "Alp's Angel \r\nChocolates";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.BackColor = Color.Transparent;
            label4.Font = new Font("Segoe UI", 19.8000011F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label4.Location = new Point(387, 125);
            label4.Name = "label4";
            label4.Size = new Size(193, 46);
            label4.TabIndex = 6;
            label4.Text = "Chocolates";
            // 
            // panel6
            // 
            panel6.Controls.Add(label9);
            panel6.Controls.Add(pictureBox6);
            panel6.Location = new Point(673, 467);
            panel6.Name = "panel6";
            panel6.Size = new Size(232, 233);
            panel6.TabIndex = 5;
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.Font = new Font("Segoe UI", 7.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label9.Location = new Point(16, 159);
            label9.Name = "label9";
            label9.Size = new Size(197, 34);
            label9.TabIndex = 1;
            label9.Text = "Cadbury Dairy Choco Roasted \r\nAlmond";
            // 
            // pictureBox6
            // 
            pictureBox6.BackgroundImage = (Image)resources.GetObject("pictureBox6.BackgroundImage");
            pictureBox6.BackgroundImageLayout = ImageLayout.Zoom;
            pictureBox6.Location = new Point(36, 26);
            pictureBox6.Name = "pictureBox6";
            pictureBox6.Size = new Size(161, 130);
            pictureBox6.TabIndex = 0;
            pictureBox6.TabStop = false;
            // 
            // panel5
            // 
            panel5.Controls.Add(label8);
            panel5.Controls.Add(pictureBox5);
            panel5.Location = new Point(371, 467);
            panel5.Name = "panel5";
            panel5.Size = new Size(232, 233);
            panel5.TabIndex = 4;
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Font = new Font("Segoe UI", 7.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label8.Location = new Point(12, 171);
            label8.Name = "label8";
            label8.Size = new Size(208, 17);
            label8.TabIndex = 1;
            label8.Text = "Trapa 80 Percent Dark Chocolate";
            // 
            // pictureBox5
            // 
            pictureBox5.BackgroundImage = (Image)resources.GetObject("pictureBox5.BackgroundImage");
            pictureBox5.BackgroundImageLayout = ImageLayout.Zoom;
            pictureBox5.Location = new Point(36, 26);
            pictureBox5.Name = "pictureBox5";
            pictureBox5.Size = new Size(161, 130);
            pictureBox5.TabIndex = 0;
            pictureBox5.TabStop = false;
            // 
            // panel4
            // 
            panel4.Controls.Add(label7);
            panel4.Controls.Add(pictureBox4);
            panel4.Location = new Point(78, 467);
            panel4.Name = "panel4";
            panel4.Size = new Size(232, 233);
            panel4.TabIndex = 3;
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Font = new Font("Segoe UI", 7.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label7.Location = new Point(36, 159);
            label7.Name = "label7";
            label7.Size = new Size(172, 51);
            label7.TabIndex = 1;
            label7.Text = "\r\nHershey's Bar Creamy Milk\r\n\r\n";
            // 
            // pictureBox4
            // 
            pictureBox4.BackgroundImage = (Image)resources.GetObject("pictureBox4.BackgroundImage");
            pictureBox4.BackgroundImageLayout = ImageLayout.Zoom;
            pictureBox4.Location = new Point(36, 26);
            pictureBox4.Name = "pictureBox4";
            pictureBox4.Size = new Size(161, 130);
            pictureBox4.TabIndex = 0;
            pictureBox4.TabStop = false;
            // 
            // panel3
            // 
            panel3.Controls.Add(label6);
            panel3.Controls.Add(pictureBox3);
            panel3.Location = new Point(673, 192);
            panel3.Name = "panel3";
            panel3.Size = new Size(232, 233);
            panel3.TabIndex = 2;
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Font = new Font("Segoe UI", 7.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label6.Location = new Point(36, 170);
            label6.Name = "label6";
            label6.Size = new Size(58, 17);
            label6.TabIndex = 1;
            label6.Text = "Snickers";
            label6.Click += label6_Click;
            // 
            // pictureBox3
            // 
            pictureBox3.BackgroundImage = (Image)resources.GetObject("pictureBox3.BackgroundImage");
            pictureBox3.BackgroundImageLayout = ImageLayout.Zoom;
            pictureBox3.Location = new Point(36, 26);
            pictureBox3.Name = "pictureBox3";
            pictureBox3.Size = new Size(161, 130);
            pictureBox3.TabIndex = 0;
            pictureBox3.TabStop = false;
            // 
            // panel2
            // 
            panel2.Controls.Add(label3);
            panel2.Controls.Add(pictureBox2);
            panel2.Location = new Point(371, 192);
            panel2.Name = "panel2";
            panel2.Size = new Size(232, 233);
            panel2.TabIndex = 1;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Segoe UI", 7.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label3.Location = new Point(36, 170);
            label3.Name = "label3";
            label3.Size = new Size(173, 17);
            label3.TabIndex = 1;
            label3.Text = "Mars Miniatures Chocolate";
            // 
            // pictureBox2
            // 
            pictureBox2.BackgroundImage = (Image)resources.GetObject("pictureBox2.BackgroundImage");
            pictureBox2.BackgroundImageLayout = ImageLayout.Zoom;
            pictureBox2.Location = new Point(36, 26);
            pictureBox2.Name = "pictureBox2";
            pictureBox2.Size = new Size(161, 130);
            pictureBox2.TabIndex = 0;
            pictureBox2.TabStop = false;
            // 
            // panel1
            // 
            panel1.Controls.Add(label2);
            panel1.Controls.Add(pictureBox1);
            panel1.Location = new Point(78, 192);
            panel1.Name = "panel1";
            panel1.Size = new Size(232, 233);
            panel1.TabIndex = 0;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Segoe UI", 7.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label2.Location = new Point(36, 170);
            label2.Name = "label2";
            label2.Size = new Size(172, 17);
            label2.TabIndex = 1;
            label2.Text = "Distachio Dubai Chocolate";
            // 
            // pictureBox1
            // 
            pictureBox1.BackgroundImage = (Image)resources.GetObject("pictureBox1.BackgroundImage");
            pictureBox1.BackgroundImageLayout = ImageLayout.Zoom;
            pictureBox1.Location = new Point(36, 26);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(161, 130);
            pictureBox1.TabIndex = 0;
            pictureBox1.TabStop = false;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1252, 753);
            Controls.Add(splitContainer1);
            Name = "Form1";
            Text = "Form1";
            splitContainer1.Panel1.ResumeLayout(false);
            splitContainer1.Panel1.PerformLayout();
            splitContainer1.Panel2.ResumeLayout(false);
            splitContainer1.Panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)splitContainer1).EndInit();
            splitContainer1.ResumeLayout(false);
            panel6.ResumeLayout(false);
            panel6.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox6).EndInit();
            panel5.ResumeLayout(false);
            panel5.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox5).EndInit();
            panel4.ResumeLayout(false);
            panel4.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox4).EndInit();
            panel3.ResumeLayout(false);
            panel3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox3).EndInit();
            panel2.ResumeLayout(false);
            panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).EndInit();
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ResumeLayout(false);
        }

        #endregion

        private SplitContainer splitContainer1;
        private Button button7;
        private Button button6;
        private Button button5;
        private Button button4;
        private Button button3;
        private Button button2;
        private Button button1;
        private Panel panel1;
        private PictureBox pictureBox1;
        private Panel panel3;
        private PictureBox pictureBox3;
        private Panel panel2;
        private PictureBox pictureBox2;
        private Panel panel6;
        private PictureBox pictureBox6;
        private Panel panel5;
        private PictureBox pictureBox5;
        private Panel panel4;
        private PictureBox pictureBox4;
        private Label label1;
        private Label label2;
        private Label label5;
        private Label label4;
        private Label label6;
        private Label label3;
        private Label label9;
        private Label label8;
        private Label label7;
    }
}
