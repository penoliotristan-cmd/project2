﻿namespace WinFormsApp1
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form2));
            splitContainer1 = new SplitContainer();
            button2 = new Button();
            button1 = new Button();
            label1 = new Label();
            button3 = new Button();
            button4 = new Button();
            button5 = new Button();
            button6 = new Button();
            button7 = new Button();
            label5 = new Label();
            panel1 = new Panel();
            pictureBox1 = new PictureBox();
            panel2 = new Panel();
            pictureBox2 = new PictureBox();
            panel3 = new Panel();
            pictureBox3 = new PictureBox();
            panel4 = new Panel();
            pictureBox4 = new PictureBox();
            panel5 = new Panel();
            pictureBox5 = new PictureBox();
            panel6 = new Panel();
            pictureBox6 = new PictureBox();
            panel7 = new Panel();
            pictureBox7 = new PictureBox();
            panel8 = new Panel();
            pictureBox8 = new PictureBox();
            panel9 = new Panel();
            pictureBox9 = new PictureBox();
            panel10 = new Panel();
            pictureBox10 = new PictureBox();
            panel11 = new Panel();
            pictureBox11 = new PictureBox();
            panel12 = new Panel();
            pictureBox12 = new PictureBox();
            label2 = new Label();
            ((System.ComponentModel.ISupportInitialize)splitContainer1).BeginInit();
            splitContainer1.Panel1.SuspendLayout();
            splitContainer1.Panel2.SuspendLayout();
            splitContainer1.SuspendLayout();
            panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).BeginInit();
            panel3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox3).BeginInit();
            panel4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox4).BeginInit();
            panel5.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox5).BeginInit();
            panel6.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox6).BeginInit();
            panel7.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox7).BeginInit();
            panel8.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox8).BeginInit();
            panel9.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox9).BeginInit();
            panel10.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox10).BeginInit();
            panel11.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox11).BeginInit();
            panel12.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox12).BeginInit();
            SuspendLayout();
            // 
            // splitContainer1
            // 
            splitContainer1.Dock = DockStyle.Fill;
            splitContainer1.Location = new Point(0, 0);
            splitContainer1.Name = "splitContainer1";
            // 
            // splitContainer1.Panel1
            // 
            splitContainer1.Panel1.BackColor = Color.FromArgb(78, 52, 46);
            splitContainer1.Panel1.Controls.Add(button7);
            splitContainer1.Panel1.Controls.Add(button6);
            splitContainer1.Panel1.Controls.Add(button5);
            splitContainer1.Panel1.Controls.Add(button4);
            splitContainer1.Panel1.Controls.Add(button3);
            splitContainer1.Panel1.Controls.Add(button2);
            splitContainer1.Panel1.Controls.Add(button1);
            splitContainer1.Panel1.Controls.Add(label1);
            // 
            // splitContainer1.Panel2
            // 
            splitContainer1.Panel2.BackgroundImage = (Image)resources.GetObject("splitContainer1.Panel2.BackgroundImage");
            splitContainer1.Panel2.BackgroundImageLayout = ImageLayout.Stretch;
            splitContainer1.Panel2.Controls.Add(label2);
            splitContainer1.Panel2.Controls.Add(panel12);
            splitContainer1.Panel2.Controls.Add(panel11);
            splitContainer1.Panel2.Controls.Add(panel10);
            splitContainer1.Panel2.Controls.Add(panel9);
            splitContainer1.Panel2.Controls.Add(panel8);
            splitContainer1.Panel2.Controls.Add(panel7);
            splitContainer1.Panel2.Controls.Add(panel6);
            splitContainer1.Panel2.Controls.Add(panel5);
            splitContainer1.Panel2.Controls.Add(panel4);
            splitContainer1.Panel2.Controls.Add(panel3);
            splitContainer1.Panel2.Controls.Add(panel2);
            splitContainer1.Panel2.Controls.Add(panel1);
            splitContainer1.Panel2.Controls.Add(label5);
            splitContainer1.Size = new Size(1252, 753);
            splitContainer1.SplitterDistance = 288;
            splitContainer1.TabIndex = 0;
            // 
            // button2
            // 
            button2.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            button2.Location = new Point(66, 254);
            button2.Name = "button2";
            button2.Size = new Size(152, 41);
            button2.TabIndex = 5;
            button2.Text = "All Products";
            button2.UseVisualStyleBackColor = true;
            // 
            // button1
            // 
            button1.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            button1.Location = new Point(66, 198);
            button1.Name = "button1";
            button1.Size = new Size(152, 41);
            button1.TabIndex = 4;
            button1.Text = "Top Picks";
            button1.UseVisualStyleBackColor = true;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI", 22.2F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label1.ForeColor = SystemColors.ButtonHighlight;
            label1.Location = new Point(44, 55);
            label1.Name = "label1";
            label1.Size = new Size(207, 100);
            label1.TabIndex = 3;
            label1.Text = "Alp's Angel\r\n Chocolate";
            label1.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // button3
            // 
            button3.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            button3.Location = new Point(66, 318);
            button3.Name = "button3";
            button3.Size = new Size(152, 41);
            button3.TabIndex = 2;
            button3.Text = "Chocolates";
            button3.UseVisualStyleBackColor = true;
            // 
            // button4
            // 
            button4.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            button4.Location = new Point(66, 384);
            button4.Name = "button4";
            button4.Size = new Size(152, 41);
            button4.TabIndex = 6;
            button4.Text = "Ratings";
            button4.UseVisualStyleBackColor = true;
            // 
            // button5
            // 
            button5.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            button5.Location = new Point(66, 445);
            button5.Name = "button5";
            button5.Size = new Size(152, 41);
            button5.TabIndex = 7;
            button5.Text = "Your Order Reciepts";
            button5.UseVisualStyleBackColor = true;
            // 
            // button6
            // 
            button6.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            button6.Location = new Point(66, 511);
            button6.Name = "button6";
            button6.Size = new Size(152, 41);
            button6.TabIndex = 8;
            button6.Text = "Categories";
            button6.UseVisualStyleBackColor = true;
            // 
            // button7
            // 
            button7.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            button7.Location = new Point(66, 573);
            button7.Name = "button7";
            button7.Size = new Size(152, 41);
            button7.TabIndex = 9;
            button7.Text = "Promos";
            button7.UseVisualStyleBackColor = true;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.BackColor = Color.Transparent;
            label5.Font = new Font("Segoe UI", 22.2F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label5.Location = new Point(24, 28);
            label5.Name = "label5";
            label5.Size = new Size(229, 100);
            label5.TabIndex = 8;
            label5.Text = "Alp's Angel \r\nChocolates";
            // 
            // panel1
            // 
            panel1.Controls.Add(pictureBox1);
            panel1.Location = new Point(60, 150);
            panel1.Name = "panel1";
            panel1.Size = new Size(171, 158);
            panel1.TabIndex = 9;
            // 
            // pictureBox1
            // 
            pictureBox1.Location = new Point(39, 28);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(90, 85);
            pictureBox1.TabIndex = 0;
            pictureBox1.TabStop = false;
            // 
            // panel2
            // 
            panel2.Controls.Add(pictureBox2);
            panel2.Location = new Point(288, 150);
            panel2.Name = "panel2";
            panel2.Size = new Size(171, 158);
            panel2.TabIndex = 10;
            // 
            // pictureBox2
            // 
            pictureBox2.Location = new Point(39, 28);
            pictureBox2.Name = "pictureBox2";
            pictureBox2.Size = new Size(90, 85);
            pictureBox2.TabIndex = 0;
            pictureBox2.TabStop = false;
            // 
            // panel3
            // 
            panel3.Controls.Add(pictureBox3);
            panel3.Location = new Point(506, 150);
            panel3.Name = "panel3";
            panel3.Size = new Size(171, 158);
            panel3.TabIndex = 10;
            // 
            // pictureBox3
            // 
            pictureBox3.Location = new Point(39, 28);
            pictureBox3.Name = "pictureBox3";
            pictureBox3.Size = new Size(90, 85);
            pictureBox3.TabIndex = 0;
            pictureBox3.TabStop = false;
            // 
            // panel4
            // 
            panel4.Controls.Add(pictureBox4);
            panel4.Location = new Point(742, 150);
            panel4.Name = "panel4";
            panel4.Size = new Size(171, 158);
            panel4.TabIndex = 11;
            // 
            // pictureBox4
            // 
            pictureBox4.Location = new Point(39, 28);
            pictureBox4.Name = "pictureBox4";
            pictureBox4.Size = new Size(90, 85);
            pictureBox4.TabIndex = 0;
            pictureBox4.TabStop = false;
            // 
            // panel5
            // 
            panel5.Controls.Add(pictureBox5);
            panel5.Location = new Point(60, 346);
            panel5.Name = "panel5";
            panel5.Size = new Size(171, 158);
            panel5.TabIndex = 12;
            // 
            // pictureBox5
            // 
            pictureBox5.Location = new Point(39, 28);
            pictureBox5.Name = "pictureBox5";
            pictureBox5.Size = new Size(90, 85);
            pictureBox5.TabIndex = 0;
            pictureBox5.TabStop = false;
            // 
            // panel6
            // 
            panel6.Controls.Add(pictureBox6);
            panel6.Location = new Point(288, 346);
            panel6.Name = "panel6";
            panel6.Size = new Size(171, 158);
            panel6.TabIndex = 13;
            // 
            // pictureBox6
            // 
            pictureBox6.Location = new Point(39, 28);
            pictureBox6.Name = "pictureBox6";
            pictureBox6.Size = new Size(90, 85);
            pictureBox6.TabIndex = 0;
            pictureBox6.TabStop = false;
            // 
            // panel7
            // 
            panel7.Controls.Add(pictureBox7);
            panel7.Location = new Point(506, 346);
            panel7.Name = "panel7";
            panel7.Size = new Size(171, 158);
            panel7.TabIndex = 14;
            // 
            // pictureBox7
            // 
            pictureBox7.Location = new Point(39, 28);
            pictureBox7.Name = "pictureBox7";
            pictureBox7.Size = new Size(90, 85);
            pictureBox7.TabIndex = 0;
            pictureBox7.TabStop = false;
            // 
            // panel8
            // 
            panel8.Controls.Add(pictureBox8);
            panel8.Location = new Point(742, 346);
            panel8.Name = "panel8";
            panel8.Size = new Size(171, 158);
            panel8.TabIndex = 15;
            // 
            // pictureBox8
            // 
            pictureBox8.Location = new Point(39, 28);
            pictureBox8.Name = "pictureBox8";
            pictureBox8.Size = new Size(90, 85);
            pictureBox8.TabIndex = 0;
            pictureBox8.TabStop = false;
            // 
            // panel9
            // 
            panel9.Controls.Add(pictureBox9);
            panel9.Location = new Point(742, 545);
            panel9.Name = "panel9";
            panel9.Size = new Size(171, 158);
            panel9.TabIndex = 16;
            // 
            // pictureBox9
            // 
            pictureBox9.Location = new Point(39, 28);
            pictureBox9.Name = "pictureBox9";
            pictureBox9.Size = new Size(90, 85);
            pictureBox9.TabIndex = 0;
            pictureBox9.TabStop = false;
            // 
            // panel10
            // 
            panel10.Controls.Add(pictureBox10);
            panel10.Location = new Point(506, 545);
            panel10.Name = "panel10";
            panel10.Size = new Size(171, 158);
            panel10.TabIndex = 17;
            // 
            // pictureBox10
            // 
            pictureBox10.Location = new Point(39, 28);
            pictureBox10.Name = "pictureBox10";
            pictureBox10.Size = new Size(90, 85);
            pictureBox10.TabIndex = 0;
            pictureBox10.TabStop = false;
            // 
            // panel11
            // 
            panel11.Controls.Add(pictureBox11);
            panel11.Location = new Point(288, 545);
            panel11.Name = "panel11";
            panel11.Size = new Size(171, 158);
            panel11.TabIndex = 18;
            // 
            // pictureBox11
            // 
            pictureBox11.Location = new Point(39, 28);
            pictureBox11.Name = "pictureBox11";
            pictureBox11.Size = new Size(90, 85);
            pictureBox11.TabIndex = 0;
            pictureBox11.TabStop = false;
            // 
            // panel12
            // 
            panel12.Controls.Add(pictureBox12);
            panel12.Location = new Point(60, 545);
            panel12.Name = "panel12";
            panel12.Size = new Size(171, 158);
            panel12.TabIndex = 19;
            // 
            // pictureBox12
            // 
            pictureBox12.Location = new Point(39, 28);
            pictureBox12.Name = "pictureBox12";
            pictureBox12.Size = new Size(90, 85);
            pictureBox12.TabIndex = 0;
            pictureBox12.TabStop = false;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.BackColor = Color.Transparent;
            label2.Font = new Font("Segoe UI", 18F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label2.Location = new Point(382, 87);
            label2.Name = "label2";
            label2.Size = new Size(189, 41);
            label2.TabIndex = 20;
            label2.Text = "All Products";
            // 
            // Form2
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1252, 753);
            Controls.Add(splitContainer1);
            Name = "Form2";
            Text = "Form2";
            splitContainer1.Panel1.ResumeLayout(false);
            splitContainer1.Panel1.PerformLayout();
            splitContainer1.Panel2.ResumeLayout(false);
            splitContainer1.Panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)splitContainer1).EndInit();
            splitContainer1.ResumeLayout(false);
            panel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)pictureBox2).EndInit();
            panel3.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)pictureBox3).EndInit();
            panel4.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)pictureBox4).EndInit();
            panel5.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)pictureBox5).EndInit();
            panel6.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)pictureBox6).EndInit();
            panel7.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)pictureBox7).EndInit();
            panel8.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)pictureBox8).EndInit();
            panel9.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)pictureBox9).EndInit();
            panel10.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)pictureBox10).EndInit();
            panel11.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)pictureBox11).EndInit();
            panel12.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)pictureBox12).EndInit();
            ResumeLayout(false);
        }

        #endregion

        private SplitContainer splitContainer1;
        private Label label1;
        private Button button1;
        private Button button2;
        private Button button3;
        private Button button4;
        private Button button5;
        private Button button6;
        private Button button7;
        private Label label5;
        private Panel panel1;
        private PictureBox pictureBox1;
        private Panel panel8;
        private PictureBox pictureBox8;
        private Panel panel7;
        private PictureBox pictureBox7;
        private Panel panel6;
        private PictureBox pictureBox6;
        private Panel panel5;
        private PictureBox pictureBox5;
        private Panel panel4;
        private PictureBox pictureBox4;
        private Panel panel3;
        private PictureBox pictureBox3;
        private Panel panel2;
        private PictureBox pictureBox2;
        private Panel panel12;
        private PictureBox pictureBox12;
        private Panel panel11;
        private PictureBox pictureBox11;
        private Panel panel10;
        private PictureBox pictureBox10;
        private Panel panel9;
        private PictureBox pictureBox9;
        private Label label2;
    }
}